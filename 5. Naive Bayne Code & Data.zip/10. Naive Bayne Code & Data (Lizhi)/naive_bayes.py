from __future__ import print_function
import math
import pandas as pd
class Bayes_Classifier:

    def __init__(self):
        self.vocabulary = []
        self.positivevoc = []
        self.negativevoc = []
        self.posdict = []
        self.negdict = []
        self.wordnum = 0
        self.stopwords = ['about','after','again','against','all','and','any','are',
            "aren't",'because','been','before','being','below','between','both',
            'but',"can't",'cannot','could',"could't",'did',"did't",'does',"doesn't",
            'doing',"don't",'during','each','for','from','further','had',
            "hadn't",'has','that','now',"it's",'the',"i'm",'this','was','its','they',
            'just','have','with','can','she','you','movie','her','actually','were','what','may',
            'there','dont','also','who','what','which',"there's",'ourselves', 'hers', 'between', 
            'yourself', 'but', 'again', 'there', 'about', 'once', 'during', 'out', 'very',
            'having', 'with', 'they', 'own', 'some', 'for','its', 'yours', 'such', 'into',
            'most', 'itself', 'other', 'off', 'who', 'from', 'him',
            'each', 'the', 'themselves', 'until', 'below', 'are','these', 'your', 'his', 'through', 
            'don', 'nor', 'me', 'were', 'her', 'more', 'himself', 'this', 'down', 
            'should', 'our', 'their', 'while', 'above', 'both','ours',
            'had', 'she', 'all','when','any', 'before', 'them', 'same', 
            'and', 'been', 'have', 'in', 'will','does', 'yourselves', 'then', 
            'that', 'because', 'what', 'over', 'why','can', 'did', 'not', 'now',
            'under','you', 'herself', 'has', 'just', 'where', 'too', 'only', 
            'myself', 'which', 'those', 'i', 'after', 'few', 'whom','being',"i've" 
            'theirs', 'my', 'against','doing','how', 'further', 'was', 'here', 'than']
        self.posdict = dict([])
        self.negdict = dict([])
        self.nn = 0.0
        self.pp = 0.0
        self.n = 0.0
        self.p = 0.0
        
    def train(self,filename):
        [a,b,c] = self.extract(filename)
        self.vocabulary = self.word(a)
        self.wordnum = len({}.fromkeys(self.vocabulary).keys())
        self.negativevoc =self.word(c)
        self.positivevoc =self.word(b)
        self.negdict = self.temp(self.negativevoc)
        self.posdict = self.temp(self.positivevoc)
        self.n = self.nn /(self.nn+self.pp)
        self.p = self.pp /(self.nn+self.pp)


    def classify(self,filename):
        
        words = [i for i in filename if len(i) > 2]
        words = [i for i in filename if i not in self.stopwords]
        result = self.classifier(words)
        return result
            
    
    def classifier(self,words):
        pos = 0.0
        neg = 0.0
        dp = float(len(self.positivevoc)+self.wordnum)
        dn = float(len(self.negativevoc)+self.wordnum)
        for i in words:
            p = 0.0
            n = 0.0
            if i not in self.posdict.keys():
                p = math.log10(1/dp)
            else:
                p = math.log10((self.posdict[i]+1)/dp)
            pos = pos + p
            if i not in self.negdict.keys():
                n = math.log10(1/dn)
            else:
                n = math.log10((self.negdict[i]+1)/dn)
            neg = neg + n
        pos = pos+math.log10(self.p)
        neg = neg+math.log10(self.n)
        if pos > neg:
            return '1'
        else:
            return '-1'
    
    def extract(self,filename):
        total = []
        pos = []
        neg = []
        with open(filename,'rt') as f:
            lines = f.readlines()
        for line in lines:
            line = line.replace('\n','')
            fields = line.split('|')
            wID = int(fields[1])
            sentiment = fields[2].lower()
            total.append(sentiment)
            if wID == 1:
                self.nn = self.nn + 1
                neg.append(sentiment)
            elif wID == 5:
                self.pp = self.pp + 1
                pos.append(sentiment)
        
        return [total,pos,neg]

    def word(self,total):
        myfile= []
        for i in total:
            for j in i.split(' '):
                myfile.append(j)
        myfile=[i for i in myfile if len(i)>2]
        b=[i for i in myfile if i not in self.stopwords]
        return b
    
    def temp(self,total):
        a = {}.fromkeys(total).keys()
        temp = [(i,total.count(i)) for i in a]
        self.b = [total.count(i) for i in a]
        ab=dict(temp)
        return ab
            
        


    
