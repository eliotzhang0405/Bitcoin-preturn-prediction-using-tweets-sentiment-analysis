#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Mar 13 20:29:37 2019

@author: ramen
"""

import pandas as pd
import statsmodels.api as sm
import numpy as np
import os

def averagenum(num):
    nsum = 0
    for i in range(len(num)-2):
        nsum += num[i]
    return nsum / len(num)

os.chdir('/Users/ramen/Desktop/NLP')
bitcoin = pd.read_csv('Bitcoin.csv')
df = pd.read_csv("normalized_score_new.csv")
data = pd.DataFrame(bitcoin['direction_lead3'])
data['direction'] = bitcoin['direction']
data['TMD_score']=df['TMD_score']
data['vigour_score']=df['vigour_score']
data['fatigue_score']=df['fatigue_score']
data['intercept'] = 1.0
data = data.dropna()
Pre = [0,0,0,0,0]
list_train_cols = [['direction','intercept'],['direction','TMD_score','intercept'],['direction','TMD_score','vigour_score','intercept'],['direction','TMD_score','fatigue_score','intercept'],['direction','TMD_score','vigour_score','fatigue_score','intercept']]
for j in range(len(list_train_cols)):
    train_cols = list_train_cols[j]
    M = []
    for i in range(61, len(data)):
        logit = sm.Logit(data.loc[:i]['direction_lead3'], data.loc[:i][train_cols])
        result = logit.fit()
        combos = data.loc[i+2:i+7].copy()
        combos['predict'] = result.predict(combos[train_cols])
        combos ['M'] = abs(combos['predict']-(1-combos['direction_lead3']))
        M.append(np.mean(combos ['M']))
        Pre[j] = averagenum(M)
print('B', Pre[0])
print('T-B', Pre[1])
print('T-V-B', Pre[2])
print('T-F-B', Pre[3])
print('T-V-F-B', Pre[4])