# -*- coding: utf-8 -*-
"""
Created on Sat Feb 16 20:32:22 2019

@author: anhoc
"""
import os
import pandas as pd
import statsmodels.api as sm
import numpy as np
os.chdir(r'G:\Natural language Processing')
df1 = pd.read_csv('normalized_score_new.csv')
print(df1.head())
df2 = pd.read_csv('Bitcoin.csv')
print(df2.head())
total=df1.merge(df2,how='inner',left_index=True, right_index=True)
total=total.dropna(subset=['norm_return_lead1', 'norm_return_lead2', 'norm_return_lead3','norm_return_lead4','norm_return_lead5'])
#MAPE regression of return by moods
def linear_regR(total, ret, mood):
    print("\n", "For regression of "+ret, "by", mood)
    x = total[mood]
    y = total[ret]
    model = sm.OLS(y, sm.add_constant(x)).fit()
    #print ("\n" ,model.summary())
    return model.rsquared
def linear_regP(total, ret, mood):
    print("\n", "For regression of "+ret, "by", mood)
    x = total[mood]
    y = total[ret]
    model = sm.OLS(y, sm.add_constant(x)).fit()
    print ("\n" ,model.pvalues[1])
    return model.pvalues[1]


#get the p value table#
x=[]
for j in ['anger_score', 'confusion_score', 'depression_score',
       'fatigue_score', 'tension_score', 'vigour_score', 'esteem_score',
       'TMD_score']:
    y=[]
    for i in range(1,6):
        #linear_regP( total ,'norm_return_lead'+str(i), j)
        y.append(linear_regP( total ,'norm_return_lead'+str(i), j))
    x.append(y)
df4 = pd.DataFrame(np.array(x), columns=['norm_return_lead1', 'norm_return_lead2', 'norm_return_lead3',
       'norm_return_lead4', 'norm_return_lead5']) 
df4.index=pd.Series(['anger_score', 'confusion_score', 'depression_score',
       'fatigue_score', 'tension_score', 'vigour_score', 'esteem_score',
       'TMD_score'])  
#mape for the prediction model use bitcoin past momentum only   
y2=[]
for i in range(60,360):
        y=total['norm_return_lead3'][:i]
        x=total['norm_return'][:i]
        model = sm.OLS(y, sm.add_constant(x)).fit()
        y_pred=model.params[0]+total['norm_return'][i]*model.params[1]
        difference=abs(y_pred-total['norm_return_lead3'][i])/total['norm_return_lead3'][i]
        y2.append(difference)    
print('mape for the prediction model use bitcoin past momentum only is',  np.mean(y2))
#mape for the prediction model use bitcoin past momentum and tmd score
y2=[]
for i in range(60,360):
        y=total['norm_return_lead3'][:i]
        x=total[['norm_return','TMD_score']][:i]
        model = sm.OLS(y, sm.add_constant(x)).fit()
        y_pred=model.params[0]+total['norm_return'][i]*model.params[1]+total['TMD_score'][i]*model.params[2]
        difference=abs(y_pred-total['norm_return_lead3'][i])/total['norm_return_lead3'][i]
        y2.append(difference)
print(' mape for the prediction model use bitcoin past momentum and tmd score is ',  np.mean(y2))
    
#mape for the prediction model use bitcoin past momentum, tmd score and vigour score
y2=[]
for i in range(60,360):
        y=total['norm_return_lead3'][:i]
        x=total[['norm_return','TMD_score','vigour_score']][:i]
        model = sm.OLS(y, sm.add_constant(x)).fit()
        y_pred=model.params[0]+total['norm_return'][i]*model.params[1]+total['TMD_score'][i]*model.params[2]+total['vigour_score'][i]*model.params[3]
        difference=abs(y_pred-total['norm_return_lead3'][i])/total['norm_return_lead3'][i]
        y2.append(difference)
print(' mape for the prediction model use bitcoin past momentum, tmd score and vigour score is ',  np.mean(y2))
#mape for the prediction model use bitcoin past momentum, tmd score and fatigue score
y2=[]
for i in range(60,360):
        y=total['norm_return_lead3'][:i]
        x=total[['norm_return','TMD_score','fatigue_score']][:i]
        model = sm.OLS(y, sm.add_constant(x)).fit()
        y_pred=model.params[0]+total['norm_return'][i]*model.params[1]+total['TMD_score'][i]*model.params[2]+total['fatigue_score'][i]*model.params[3]
        difference=abs(y_pred-total['norm_return_lead3'][i])/total['norm_return_lead3'][i]
        y2.append(difference)
print('mape for the prediction model use bitcoin past momentum, tmd score and fatigue score is ',  np.mean(y2))
#mape for the prediction model use tmd score, vigour score and fatigue score
y2=[]
for i in range(60,360):
        y=total['norm_return_lead3'][:i]
        x=total[['TMD_score','fatigue_score','vigour_score']][:i]
        model = sm.OLS(y, sm.add_constant(x)).fit()
        y_pred=model.params[0]+total['TMD_score'][i]*model.params[1]+total['fatigue_score'][i]*model.params[2]+total['vigour_score'][i]*model.params[3]
        difference=abs(y_pred-total['norm_return_lead3'][i])/total['norm_return_lead3'][i]
        y2.append(difference)
print('mape for the prediction model use bitcoin past momentum, tmd score, vigour score and fatigue score is ',  np.mean(y2))
    
