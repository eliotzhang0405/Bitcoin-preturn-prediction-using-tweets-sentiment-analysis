# -*- coding: utf-8 -*-
"""
Created on Sat Feb 16 20:32:22 2019

@author: anhoc
"""
import os
import pandas as pd
import statsmodels.api as sm
import numpy as np
os.chdir(r'G:\Natural language Processing')
df1 = pd.read_csv('normalized_scores.csv')
print(df1.head())
df2 = pd.read_csv('Bitcoin.csv')
print(df2.head())
total=df1.merge(df2,how='inner',left_index=True, right_index=True)
total=total.dropna(subset=['norm_return_lead1', 'norm_return_lead2', 'norm_return_lead3','norm_return_lead4','norm_return_lead5'])
#MAPE regression of return by moods
def linear_regR(total, ret, mood):
    print("\n", "For regression of "+ret, "by", mood)
    x = total[mood]
    y = total[ret]
    model = sm.OLS(y, sm.add_constant(x)).fit()
    #print ("\n" ,model.summary())
    return model.rsquared
def linear_regP(total, ret, mood):
    print("\n", "For regression of "+ret, "by", mood)
    x = total[mood]
    y = total[ret]
    model = sm.OLS(y, sm.add_constant(x)).fit()
    print ("\n" ,model.pvalues[1])
    return model.pvalues[1]
x=[]
for j in ['anger_score', 'confusion_score', 'depression_score',
       'fatigue_score', 'tension_score', 'vigour_score', 'esteem_score',
       'TMD_score']:
    y=[]
    for i in range(1,6):
        #linear_regP( total ,'norm_return_lead'+str(i), j)
        y.append(linear_regP( total ,'norm_return_lead'+str(i), j))
    x.append(y)
df4 = pd.DataFrame(np.array(x), columns=['norm_return_lead1', 'norm_return_lead2', 'norm_return_lead3',
       'norm_return_lead4', 'norm_return_lead5']) 
df4.index=pd.Series(['anger_score', 'confusion_score', 'depression_score',
       'fatigue_score', 'tension_score', 'vigour_score', 'esteem_score',
       'TMD_score'])      

x_ret=[]
for j in ['anger_score', 'confusion_score', 'depression_score',
       'fatigue_score', 'tension_score', 'vigour_score', 'esteem_score',
       'TMD_score']:
    y=[]
    for i in range(1,6):
        #linear_regP( total ,'norm_return_lead'+str(i), j)
        y.append(linear_regP( total ,'adjust_close_lead'+str(i), j))
    x_ret.append(y)
df_ret = pd.DataFrame(np.array(x_ret), columns=['adjust_close_lead1',
       'adjust_close_lead2', 'adjust_close_lead3', 'adjust_close_lead4',
       'adjust_close_lead5']) 
df_ret.index=pd.Series(['anger_score', 'confusion_score', 'depression_score',
       'fatigue_score', 'tension_score', 'vigour_score', 'esteem_score',
       'TMD_score'])          
x1=[]
x2=[]
for a in ['anger_score', 'confusion_score', 'depression_score',
       'fatigue_score', 'tension_score', 'vigour_score', 'esteem_score',
       'TMD_score']:
    list1=['anger_score', 'confusion_score', 'depression_score',
       'fatigue_score', 'tension_score', 'vigour_score', 'esteem_score',
       'TMD_score']
    list1.remove(a)
    for b in list1:
        y1=[]
        for c in range(1,6):
            #linear_regP( total ,'norm_return_lead'+str(i), j)
            y1.append(linear_regR( total ,'norm_return_lead'+str(i), [a,b]))
        x1.append(y1)
        x2.append(a+' '+b)
df5 = pd.DataFrame(np.array(x1), columns=['norm_return_lead1', 'norm_return_lead2', 'norm_return_lead3',
       'norm_return_lead4', 'norm_return_lead5']) 
df5.index=pd.Series(x2)      
for j in ['anger_score', 'confusion_score', 'depression_score',
       'fatigue_score', 'tension_score', 'vigour_score', 'esteem_score']:
    y2=[]
    for i in range(60,357):
        y=total['norm_return_lead3'][:i]
        x=total[['TMD_score','norm_return',j]][:i]
        model = sm.OLS(y, sm.add_constant(x)).fit()
        y_pred=model.params[0]+total['TMD_score'][i]*model.params[1]+total['norm_return'][i]*model.params[2]+total[j][i]*model.params[3]
        difference=abs(y_pred-total['norm_return_lead3'][i])/total['norm_return_lead3'][i]
        y2.append(difference)
    print(j, ' TMD_score ',  np.mean(y2))
    

