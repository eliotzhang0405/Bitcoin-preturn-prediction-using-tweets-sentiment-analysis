#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np


# In[2]:


f = open(r'D:\NLP\data\positive-words.txt', 'r')
word_positive = f.read()
f.close()
word_positive = word_positive.split('\n')

f = open(r'D:\NLP\data\negative-words.txt', 'r')
word_negative = f.read()
f.close()
word_negative = word_negative.split('\n')


# In[3]:


print(len(word_positive))
print(len(word_negative))


# In[4]:


df_tweets = pd.read_csv(r'D:\NLP\data\tokenized.csv')
df_tweets.columns


# In[5]:


df_tweets['token'] = [t[2:len(df_tweets['token'][0])-2].split('\', \'') for t in df_tweets['token']]


# In[6]:


for i in range(len(df_tweets)):
    df_tweets.loc[i,'positive_counts'] = np.isin(df_tweets['token'][i], word_positive).sum()
    df_tweets.loc[i,'negative_counts'] = np.isin(df_tweets['token'][i], word_negative).sum()


# In[7]:


df_tweets.to_csv(r'D:\NLP\data\postive_negative_labeled.csv')

