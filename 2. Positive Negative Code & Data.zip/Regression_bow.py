#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import statsmodels.api as sm
import numpy as np
import matplotlib.pyplot as plt


# In[2]:


path = r'D:\NLP\data'
df_psitive_and_negative = pd.read_csv(path + '\postive_negative_counted.csv')
number_of_token = [len(x[2:len(x)-2].split('\', \'')) for x in df_psitive_and_negative['token']]
df_psitive_and_negative['number_of_token'] = number_of_token
df_psitive_and_negative['positive_counts'] = df_psitive_and_negative['positive_counts']/df_psitive_and_negative['number_of_token']
df_psitive_and_negative['negative_counts'] = df_psitive_and_negative['negative_counts']/df_psitive_and_negative['number_of_token']


# In[3]:


bitcoin_price = pd.read_csv(path + '\BTC-USD.csv')
bitcoin_price.drop(index = 0,inplace=True)
bitcoin_price['daily return'] = [float(x[:len(x)-1])/100 for x in bitcoin_price['daily return']]
bitcoin_price.to_csv(r'D:\NLP\data\bitcoin_final.csv')


# In[4]:


bitcoin_price.reset_index(drop=True, inplace=True)
bitcoin_price


# In[5]:


df_regression = df_psitive_and_negative.loc[:,['date', 'positive_counts', 'negative_counts','number_of_token']]
df_regression['positive_lag_1'] = df_regression['positive_counts'].shift(1)
df_regression['negative_lag_1'] = df_regression['negative_counts'].shift(1)
df_regression['positive_lag_2'] = df_regression['positive_counts'].shift(2)
df_regression['negative_lag_2'] = df_regression['negative_counts'].shift(2)
df_regression['positive_lead_1'] = df_regression['positive_counts'].shift(-1)
df_regression['negative_lead_1'] = df_regression['negative_counts'].shift(-1)
df_regression['positive_lead_2'] = df_regression['positive_counts'].shift(-2)
df_regression['negative_lead_2'] = df_regression['negative_counts'].shift(-2)
df_regression['relative'] = df_regression['positive_counts'] / df_regression['negative_counts']
df_regression['return'] = bitcoin_price['daily return']
df_regression.to_csv(r'D:\NLP\data\regression_input.csv')


# In[6]:


print(df_regression['return'].mean())
print(df_regression['return'].std())
print(df_psitive_and_negative['number_of_token'].mean())
print(df_psitive_and_negative['number_of_token'].std())
print(df_regression['positive_counts'].mean())
print(df_regression['positive_counts'].std())
print(df_regression['negative_counts'].mean())
print(df_regression['negative_counts'].std())
print(df_psitive_and_negative[['positive_counts','negative_counts']].corr())


# In[7]:


def sentiment_return_regression(input_list):
    df_temp = df_regression[input_list+['return']].dropna()
    y = df_temp['return']
    x = df_temp[input_list]
    model = sm.OLS(y, sm.add_constant(x)).fit()
    print(model.summary())
    


# In[8]:


#rolling windows
def RollingOLS(input_list, windows=30):
    df_temp = df_regression[input_list+['return']].dropna()
    for row in range(30,len(df_temp)):
        y = df_temp['return'][row - windows:row]
        x = df_temp[input_list][row - windows:row]
        model = sm.OLS(y, sm.add_constant(x)).fit()
        df_temp.loc[row,'beta_1'] = model.params[1]
        df_temp.loc[row,'p_values_1'] = model.pvalues[1]
        df_temp.loc[row,'issignificant_1'] = model.pvalues[1] < 0.05
        df_temp.loc[row,'standard_error_1'] = model.bse[1]
        
        df_temp.loc[row,'beta_2'] = model.params[2]
        df_temp.loc[row,'p_values_2'] = model.pvalues[2]
        df_temp.loc[row,'issignificant_2'] = model.pvalues[2] < 0.05
        df_temp.loc[row,'standard_error_2'] = model.bse[2]
    
    df_temp.dropna(inplace=True)
    plt.figure(figsize=(16,9))
    plt.plot(df_temp['beta_1'])
    plt.plot(df_temp['beta_1'] + df_temp['standard_error_1'])
    plt.plot(df_temp['beta_1'] - df_temp['standard_error_1'])
    plt.title('value of beta 1')
    plt.legend(['Beta', 'Beta + se', 'Beta - se'], loc='upper left')
    plt.show()
    plt.figure(figsize=(16,9))
    plt.title('p value of beta 1')
    plt.plot(df_temp['p_values_1'])
    
    plt.figure(figsize=(16,9))
    plt.plot(df_temp['beta_2'])
    plt.plot(df_temp['beta_2'] + df_temp['standard_error_2'])
    plt.plot(df_temp['beta_2'] - df_temp['standard_error_2'])
    plt.title('value of beta 2')
    plt.legend(['Beta', 'Beta + se', 'Beta - se'], loc='upper left')
    plt.show()
    plt.figure(figsize=(16,9))
    plt.title('p value of beta 2')
    plt.plot(df_temp['p_values_2'])


# In[9]:


sentiment_return_regression(['positive_counts','negative_counts'])
RollingOLS(['positive_counts','negative_counts'])


# In[10]:


sentiment_return_regression(['positive_lag_1','negative_lag_1'])
RollingOLS(['positive_lag_1','negative_lag_1'])


# In[11]:


sentiment_return_regression(['positive_lag_2','negative_lag_2'])
RollingOLS(['positive_lag_2','negative_lag_2'])


# In[12]:


sentiment_return_regression(['positive_lead_1','negative_lead_1'])
RollingOLS(['positive_lead_1','negative_lead_1'])


# In[13]:


sentiment_return_regression(['positive_lead_2','negative_lead_2'])
RollingOLS(['positive_lead_2','negative_lead_2'])


# In[14]:


plt.figure(figsize=(16,9))
plt.plot(df_regression['return'][:60])
plt.plot(df_regression['positive_lag_1'][:60])
plt.plot(df_regression['negative_lag_1'][:60])
plt.legend(['Return', 'Postive_lag_1', 'Negative_lag_1'], loc='upper left')
plt.show()


# In[ ]:




