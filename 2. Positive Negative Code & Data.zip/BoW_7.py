#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import os
import numpy as np
from nltk.stem import WordNetLemmatizer
import nltk
nltk.download('wordnet')

os.chdir(r'D:\NLP\data')

df_libs = pd.read_csv('word_7_drop_duplicates.csv')
df_tokenized = pd.read_csv('tokenized_new.csv')


# In[2]:


df_tokenized['token'] = [t[2:len(df_tokenized['token'][0])-2].split('\', \'') for t in df_tokenized['token']]

lmtzr = WordNetLemmatizer()

anger = list(df_libs.copy().dropna(subset = ['Anger'])['Anger'])
anger = [lmtzr.lemmatize(x) for x in anger]
confusion = list(df_libs.copy().dropna(subset = ['Confusion'])['Confusion'])
confusion = [lmtzr.lemmatize(x) for x in confusion]
depression = list(df_libs.copy().dropna(subset = ['Depression'])['Depression'])
depression = [lmtzr.lemmatize(x) for x in depression]
fatigue = list(df_libs.copy().dropna(subset = ['Fatigue'])['Fatigue'])
fatigue = [lmtzr.lemmatize(x) for x in fatigue]
tension = list(df_libs.copy().dropna(subset = ['Tension'])['Tension'])
tension = [lmtzr.lemmatize(x) for x in tension]
vigour = list(df_libs.copy().dropna(subset = ['Vigour'])['Vigour'])
vigour = [lmtzr.lemmatize(x) for x in vigour]
esteem = list(df_libs.copy().dropna(subset = ['Esteem Related Effect'])['Esteem Related Effect'])
esteem = [lmtzr.lemmatize(x) for x in esteem]
total = anger + confusion + depression + fatigue + tension + vigour + esteem

for i in range(len(df_tokenized)):
    df_tokenized.loc[i,'total_counts'] = np.isin(df_tokenized['token'][i], total).sum()
    df_tokenized.loc[i,'anger_counts'] = np.isin(df_tokenized['token'][i], anger).sum()
    df_tokenized.loc[i,'confusion_counts'] = np.isin(df_tokenized['token'][i], confusion).sum()
    df_tokenized.loc[i,'depression_counts'] = np.isin(df_tokenized['token'][i], depression).sum()
    df_tokenized.loc[i,'fatigue_counts'] = np.isin(df_tokenized['token'][i], fatigue).sum()
    df_tokenized.loc[i,'tension_counts'] = np.isin(df_tokenized['token'][i], tension).sum()
    df_tokenized.loc[i,'vigour_counts'] = np.isin(df_tokenized['token'][i], vigour).sum()
    df_tokenized.loc[i,'esteem_counts'] = np.isin(df_tokenized['token'][i], esteem).sum()

df_tokenized['anger_score'] = df_tokenized['anger_counts'] / df_tokenized['total_counts']
df_tokenized['confusion_score'] = df_tokenized['confusion_counts'] / df_tokenized['total_counts']
df_tokenized['depression_score'] = df_tokenized['depression_counts'] / df_tokenized['total_counts']
df_tokenized['fatigue_score'] = df_tokenized['fatigue_counts'] / df_tokenized['total_counts']
df_tokenized['tension_score'] = df_tokenized['tension_counts'] / df_tokenized['total_counts']
df_tokenized['vigour_score'] = df_tokenized['vigour_counts'] / df_tokenized['total_counts']
df_tokenized['esteem_score'] = df_tokenized['esteem_counts'] / df_tokenized['total_counts']

df = df_tokenized[['anger_score',
       'confusion_score', 'depression_score', 'fatigue_score',
       'tension_score', 'vigour_score', 'esteem_score']]
corr = df.corr(method = 'pearson')

df_normalized = df.copy()
for i in df.columns:
    df_normalized[i] = df_normalized[i].apply(lambda x: (x - np.mean(df_normalized[i])) / np.std(df_normalized[i]))

df_normalized['TMD_score'] = df_normalized['anger_score'] + df_normalized['confusion_score'] + df_normalized['depression_score'] + df_normalized['tension_score'] + df_normalized['fatigue_score'] - df_normalized['vigour_score'] - df_normalized['esteem_score']


# In[4]:


df_normalized.to_csv('normalized_score_new.csv')

