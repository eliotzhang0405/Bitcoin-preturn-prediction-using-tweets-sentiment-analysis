#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np


# In[2]:


f = open(r'D:\NLP\data\bow_2\Anger.txt', 'r')
word_list = f.read()
f.close()
word_Anger = pd.DataFrame([word_list.split(',\n')]).drop_duplicates().T[0]


# In[3]:


f = open(r'D:\NLP\data\bow_2\Confusion.txt', 'r')
word_list = f.read()
f.close()
word_Confusion = pd.DataFrame([word_list.split(',\n')]).drop_duplicates().T[0]


# In[4]:


f = open(r'D:\NLP\data\bow_2\Depression.txt', 'r')
word_list = f.read()
f.close()
word_Depression = pd.DataFrame([word_list.split(',\n')]).drop_duplicates().T[0]


# In[5]:


f = open(r'D:\NLP\data\bow_2\Esteem Related Effect.txt', 'r')
word_list = f.read()
f.close()
word_Esteem_Related_Effect = pd.DataFrame([word_list.split(',\n')]).drop_duplicates().T[0]


# In[6]:


f = open(r'D:\NLP\data\bow_2\Fatigue.txt', 'r')
word_list = f.read()
f.close()
word_Fatigue = pd.DataFrame([word_list.split(',\n')]).drop_duplicates().T[0]


# In[7]:


f = open(r'D:\NLP\data\bow_2\Tension.txt', 'r')
word_list = f.read()
f.close()
word_Tension = pd.DataFrame([word_list.split(',\n')]).drop_duplicates().T[0]


# In[8]:


f = open(r'D:\NLP\data\bow_2\Vigour.txt', 'r')
word_list = f.read()
f.close()
word_Vigour = pd.DataFrame([word_list.split(',\n')]).drop_duplicates().T[0]


# In[9]:


print(len(word_Anger))
print(len(word_Confusion))
print(len(word_Depression))
print(len(word_Esteem_Related_Effect))
print(len(word_Fatigue))
print(len(word_Tension))
print(len(word_Vigour))


# In[97]:


word_Anger = list(word_Anger)
#word_Anger.remove('beside oneself')
#word_Anger.remove('bitter')
#word_Anger.remove('bummed out')
#word_Anger.remove('desperate')
#word_Anger.remove('discontented')
#word_Anger.remove('intense')
#word_Anger.remove('irritable')
#word_Anger.remove('peevish')
#word_Anger.remove('querulous')
#word_Anger.remove('rugged')
#word_Anger.remove('sharp')
#word_Anger.remove('turbulent')
#word_Anger.remove('uptight')
#word_Anger.remove('vexed')


# In[98]:


word_Tension = list(word_Tension)
#word_Tension.remove('active')
#word_Tension.remove('anguished')
#word_Tension.remove('annoyed')
#word_Tension.remove('bothered')
#word_Tension.remove('bustling')
#word_Tension.remove('dismayed')
#word_Tension.remove('distressed')
#word_Tension.remove('flustered')
#word_Tension.remove('hesitant')
#word_Tension.remove('hyper')
#word_Tension.remove('irascible')
#word_Tension.remove('irresolute')
#word_Tension.remove('perplexed')
#word_Tension.remove('perturbed')
#word_Tension.remove('shot')
#word_Tension.remove('shot to pieces')
#word_Tension.remove('shy')
#word_Tension.remove('tormented')
#word_Tension.remove('weak')


# In[87]:


word_Confusion = list(word_Confusion)
#word_Confusion.remove('abashed')
#word_Confusion.remove('fitful')
#word_Confusion.remove('gone')
#word_Confusion.remove('insecure')
#word_Confusion.remove('precarious')
#word_Confusion.remove('punchy')
#word_Confusion.remove('shot to pieces')


# In[93]:


#word_Depression = list(word_Depression)
#word_Depression.remove('bad')
#word_Depression.remove('beat')
#word_Depression.remove('debilitated')
#word_Depression.remove('prostrate')
#word_Depression.remove('strained')
#word_Depression.remove('troubled')


# In[96]:


#word_Esteem_Related_Effect = list(word_Esteem_Related_Effect)
#word_Esteem_Related_Effect.remove('bold')
#word_Esteem_Related_Effect.remove('crestfallen')
#word_Esteem_Related_Effect.remove('disconcerted')
#word_Esteem_Related_Effect.remove('distressed')
#word_Esteem_Related_Effect.remove('efficient')
#word_Esteem_Related_Effect.remove('flustered')
#word_Esteem_Related_Effect.remove('happy')
#word_Esteem_Related_Effect.remove('hesitant')
#word_Esteem_Related_Effect.remove('huffy')
#word_Esteem_Related_Effect.remove('muddled')
#word_Esteem_Related_Effect.remove('racked')
#word_Esteem_Related_Effect.remove('sorry')
#word_Esteem_Related_Effect.remove('vain')


# In[89]:


#word_Fatigue = list(word_Fatigue)
#word_Fatigue.remove('disabled')
#word_Fatigue.remove('discontented')
#word_Fatigue.remove('impatient')
#word_Fatigue.remove('punchy')
#word_Fatigue.remove('shot')
#word_Fatigue.remove('sick')


# In[80]:


#word_Vigour = list(word_Vigour)
#word_Vigour.remove('fireball')
#word_Vigour.remove('rugged')


# In[99]:


df_word_7 = pd.DataFrame([word_Anger, word_Confusion, word_Depression, word_Esteem_Related_Effect, word_Fatigue,  word_Tension, word_Vigour]).T
df_word_7.columns = ['Anger', 'Confusion', 'Depression','Esteem Related Effect','Fatigue','Tension','Vigour']
df_word_7.to_csv(r'D:\NLP\data\word_7_drop_duplicates.csv')

