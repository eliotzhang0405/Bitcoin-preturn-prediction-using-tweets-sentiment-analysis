#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
from nltk import word_tokenize, TweetTokenizer, sent_tokenize
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer


# In[2]:


path = r'D:\NLP\data'
df_tweets = pd.read_csv(path + '\\output.csv')
df_tweets.columns


# In[ ]:


#tknzr = TweetTokenizer()
#wnl = WordNetLemmatizer()
#def preprocessing(text):
#    try:
#        test = [w.lower() for w in tknzr.tokenize(text) if w.isalpha()]
#        test_no_stops = [w for w in test if w not in stopwords.words('english')]
#        test_no_stops_lemmatized = [wnl.lemmatize(w) for w in test_no_stops]
#        return test_no_stops_lemmatized
#    except:
#        print (w)


# In[3]:


tknzr = TweetTokenizer()
wnl = WordNetLemmatizer()
def preprocessing(text):
    test = [w.lower() for w in tknzr.tokenize(text) if w.isalpha()]
    test_no_stops = [w for w in test if w not in stopwords.words('english')]
    test_no_stops_lemmatized = [wnl.lemmatize(w) for w in test_no_stops]
    return test_no_stops_lemmatized


# In[4]:


test = df_tweets['text sum'].apply(preprocessing)


# In[5]:


test


# In[6]:


df_tweets['token'] = test


# In[9]:


df_tweets.to_csv(r'D:\NLP\data\tokenized.csv')

